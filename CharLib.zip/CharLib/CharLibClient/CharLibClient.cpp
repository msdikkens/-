﻿// CharLibClient.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.
//

#include <iostream>
#include "CharLib.h"
int main()
{
    char buf[1024];
    char source1[1024];
    char source2[1024];
    char target[1024];
    std::cout << "Hello World!\n";
    std::cin >> buf;
    std::cout << CharLib::Length(buf);
    std::cout << "Enter 1 string\n";
    std::cin >> source1;
    std::cout << "Enter 2 string\n";
    std::cin >> source2;
    CharLib::Concat(source1, source2, target);
    std::cout << target << '\n';
}
