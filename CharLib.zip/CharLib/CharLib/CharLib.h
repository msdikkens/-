#pragma once
namespace CharLib
{
	int Length(char* buf);
	void Concat(char* Source1, char* Souce2, char* target);
}
