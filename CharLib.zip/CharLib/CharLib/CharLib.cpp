#include "CharLib.h"
namespace CharLib
{
	int CharLib::Length(char* buf) {
		int i = 0;
		for (;; i++) {
			if (buf[i] == '\0') return i;
		}
		return i;
	}
	void Concat(char* Source1, char* Source2, char* target) {
		int i = 0;
		int j = 0;
		for (;; i++) {
			if (Source1[i] == '\0') break;
			target[i] = Source1[i];
		}
		for (;; j++) {
			target[i + j] = Source2[j];
			if (Source2[j] == '\0') break;
		}
	}
}
